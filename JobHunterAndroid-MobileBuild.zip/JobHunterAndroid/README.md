# Job Hunter AI — Android starter

This is an Android Studio project starter using Kotlin + Jetpack Compose. It includes a mobile dashboard, job-match cards, an agent chat UI, profile/preferences fields and a start/stop session UI.

## Build and run
1. Install Android Studio (current stable) on a computer.
2. Open this folder as a project in Android Studio.
3. Allow Gradle sync and install missing Android SDK components if prompted (compile SDK 35).
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run.

## Important scope note
This is a UI starter/prototype, not yet a connected autonomous service. Job discovery, real AI chat, CV PDF/DOCX parsing/generation, persistent database, background processing and platform-specific application integrations still need a backend, credentials and permitted integrations. The UI uses placeholder job data. Application submissions should be reviewed before sending; it must not bypass platform rules, CAPTCHAs, verification, or restrictions.

## Suggested next backend components
- API service (FastAPI or Node)
- PostgreSQL for profile/job/application state
- Queue worker (Redis + worker) for search, matching and document generation
- AI provider configured via server-side secret
- Job-source integrations using official APIs or permitted methods
- Document pipeline for CV/cover-letter drafts
- Review/approval state before submission
- Android client connected to authenticated API
