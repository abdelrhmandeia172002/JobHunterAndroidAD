package com.example.jobhunter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17212B)
private val Accent = Color(0xFF367C71)
private val Bg = Color(0xFFF4F6F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JobHunterApp() }
    }
}

data class Job(val title:String, val company:String, val location:String, val score:Int, val status:String)

@Composable fun JobHunterApp() {
    var tab by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var chatText by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Agent: Hi! I can help manage your job search profile and prepare applications for your review.")) }
    var profile by remember { mutableStateOf("Electrical / Energy Engineer\nSkills: Add your verified skills here\nExperience: Add your experience here") }
    var cvName by remember { mutableStateOf("No CV uploaded yet") }
    var prefs by remember { mutableStateOf("Job titles: Electrical Engineer, BMS Engineer\nLocation: Egypt\nWork mode: Any\nMinimum match: 70%") }
    val jobs = remember { listOf(
        Job("Junior Electrical Engineer", "Sample Company", "Cairo, Egypt", 91, "Review needed"),
        Job("BMS Engineer", "Sample Systems", "New Cairo, Egypt", 86, "CV draft ready"),
        Job("Energy Engineer", "Sample Energy", "Hybrid", 74, "Review needed")
    ) }
    MaterialTheme(colorScheme = lightColorScheme(primary=Accent, background=Bg, surface=Color.White)) {
        Scaffold(bottomBar = { NavigationBar {
            NavigationBarItem(tab==0,{tab=0},icon={Icon(Icons.Default.Dashboard,null)},label={Text("Home")})
            NavigationBarItem(tab==1,{tab=1},icon={Icon(Icons.Default.Work,null)},label={Text("Jobs")})
            NavigationBarItem(tab==2,{tab=2},icon={Icon(Icons.Default.Chat,null)},label={Text("Agent")})
            NavigationBarItem(tab==3,{tab=3},icon={Icon(Icons.Default.Person,null)},label={Text("Profile")})
        } }) { pad ->
            Column(Modifier.fillMaxSize().background(Bg).padding(pad).padding(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("JOB HUNTER AI", fontSize=12.sp, color=Accent, fontWeight=FontWeight.Bold); Text(when(tab){0->"Dashboard";1->"Matched jobs";2->"Agent chat";else->"Your profile"},fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink) }
                    Icon(Icons.Default.AutoAwesome, contentDescription=null, tint=Accent, modifier=Modifier.size(30.dp))
                }
                Spacer(Modifier.height(16.dp))
                when(tab) {
                    0 -> Home(running, { running=true }, { running=false }, jobs)
                    1 -> JobsScreen(jobs)
                    2 -> ChatScreen(messages, chatText, {chatText=it}, { 
                        val user=chatText.trim(); if(user.isNotEmpty()){ messages=messages+"You: $user"+"Agent: This starter app can capture your command. AI execution and job-source connections need a configured backend."; chatText="" }
                    })
                    else -> ProfileScreen(profile,{profile=it},cvName,{cvName=it},prefs,{prefs=it})
                }
            }
        }
    }
}

@Composable fun Home(running:Boolean, start:()->Unit, stop:()->Unit, jobs:List<Job>) {
    Card(colors=CardDefaults.cardColors(containerColor=Ink),shape=RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text(if(running) "Agent status: ON" else "Agent status: Idle", color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp)
            Text(if(running) "Searching is marked active locally. Connect the backend to run real searches." else "Configure your profile, then start a job-search session.", color=Color.White.copy(alpha=.75f))
            Spacer(Modifier.height(16.dp))
            Button(onClick=if(running) stop else start, colors=ButtonDefaults.buttonColors(containerColor=if(running) Color(0xFFB85C54) else Accent), modifier=Modifier.fillMaxWidth()) { Text(if(running) "STOP SESSION" else "START JOB HUNT") }
        }
    }
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Metric("Jobs", "12",Modifier.weight(1f)); Metric("Shortlist", "3",Modifier.weight(1f)); Metric("Drafts", "2",Modifier.weight(1f)) }
    Spacer(Modifier.height(16.dp)); Text("Recent matches",fontWeight=FontWeight.Bold,fontSize=18.sp,color=Ink)
    jobs.take(2).forEach { JobCard(it) }
    Spacer(Modifier.height(8.dp)); Text("Application submissions require your review in this starter build.",fontSize=12.sp,color=Color.Gray)
}
@Composable fun Metric(label:String,value:String,modifier:Modifier=Modifier){ Card(modifier,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Text(label,color=Color.Gray,fontSize=12.sp);Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=Ink)}} }
@Composable fun JobsScreen(jobs:List<Job>){ LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(jobs){JobCard(it)} } }
@Composable fun JobCard(job:Job){ Card(shape=RoundedCornerShape(18.dp)){ Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(job.title,fontWeight=FontWeight.Bold,fontSize=17.sp,color=Ink);Text(job.company,color=Color.Gray)};Text("${job.score}%",color=Accent,fontWeight=FontWeight.Bold)};Text(job.location,fontSize=13.sp);Spacer(Modifier.height(8.dp));AssistChip(onClick={},label={Text(job.status)}) ; Spacer(Modifier.height(6.dp)); Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("Review application draft")}}} }
@Composable fun ChatScreen(messages:List<String>,text:String,onText:(String)->Unit,onSend:()->Unit){
    Card(Modifier.fillMaxSize(),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(14.dp)){
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){items(messages){msg->Surface(color=if(msg.startsWith("You:")) Color(0xFFE1EFEB) else Bg,shape=RoundedCornerShape(14.dp)){Text(msg,Modifier.padding(12.dp),color=Ink)}}}
        OutlinedTextField(text,onText,label={Text("Give your agent a command")},modifier=Modifier.fillMaxWidth())
        Button(onClick=onSend,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Send,null);Spacer(Modifier.width(8.dp));Text("Send")}
    }}
}
@Composable fun ProfileScreen(profile:String,onProfile:(String)->Unit,cvName:String,onCvName:(String)->Unit,prefs:String,onPrefs:(String)->Unit){LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){
    Card(shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text("Master CV",fontWeight=FontWeight.Bold);Text(cvName,color=Color.Gray);OutlinedTextField(cvName,onCvName,label={Text("CV file name / notes")},modifier=Modifier.fillMaxWidth());Text("File-picker and PDF/DOCX parsing are planned backend-connected features.",fontSize=12.sp,color=Color.Gray)}}
    Card(shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text("Verified profile",fontWeight=FontWeight.Bold);OutlinedTextField(profile,onProfile,modifier=Modifier.fillMaxWidth(),minLines=5)}}
    Card(shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text("Job preferences",fontWeight=FontWeight.Bold);OutlinedTextField(prefs,onPrefs,modifier=Modifier.fillMaxWidth(),minLines=4)}}
    Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("Save profile (local prototype)")}
} }
